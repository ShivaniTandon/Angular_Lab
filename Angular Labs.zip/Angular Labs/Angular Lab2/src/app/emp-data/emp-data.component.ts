import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-data',
  templateUrl: './emp-data.component.html',
  styleUrls: ['./emp-data.component.css']
})
export class EmpDataComponent implements OnInit {
  id: number;
  name: string;
  sal: number;
  dept: string;
  joiningDate: string;

  constructor() { }

  ngOnInit(): void {
  }

  employees:Array<{id:number,name:string,sal:number,dept:string,joiningDate:string}>=[
    {id:1001,name:'Rahul',sal:9000,dept:'JAVA',joiningDate:'6/12/2014'},
    {id:1002,name:'Vikash',sal:11000,dept:'ORAAPS',joiningDate:'6/12/2017'},
    {id:1003,name:'Uma',sal:12000,dept:'JAVA',joiningDate:'6/12/2010'},
    {id:1004,name:'Sachin',sal:11500,dept:'ORAAPS',joiningDate:'11/12/2017'},
    {id:1005,name:'Amol',sal:7000,dept:'.NET',joiningDate:'1/1/2018'},
    {id:1006,name:'Vishal',sal:17000,dept:'BI',joiningDate:'9/12/2012'},
    {id:1007,name:'Rajita',sal:21000,dept:'BI',joiningDate:'6/7/2014'},
    {id:1008,name:'Neelima',sal:81000,dept:'TESTING',joiningDate:'6/17/2015'},
    {id:1009,name:'Daya',sal:1000,dept:'TESTING',joiningDate:'6/17/2016'} 
  ];


  sortNum(prop: string): void {
    this.employees.sort((a: EmpDataComponent, b: EmpDataComponent) => {
      return a[prop] - b[prop];
    });
  }

  sortString(prop: string): void {
    this.employees.sort((a: EmpDataComponent, b: EmpDataComponent) => {
      let A: EmpDataComponent = a;
      if (prop === "name") {
        if (a.name.toLowerCase() > b.name.toLowerCase()) return 1;
        else if (a.name.toLowerCase() < b.name.toLowerCase()) return -1;
        else return 0;
      } 
      else {
        if (a[prop] > b[prop]) return 1;
        else if (a[prop] < b[prop]) return -1;
        else return 0;
      }
    });
  }
}
