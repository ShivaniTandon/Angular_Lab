import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  id:number;
  name: string;
  salary:number;
  department:string;
  status:boolean=false;
  result:string;

  ngOnInit(): void {}

  constructor(){}

  employeeDetails:Array<{id:number,name:string,salary:number,department:string}>=[
      {id:1001,name:"Rahul",salary:9000,department:"Java"},
      {id:1002,name:"Sachin",salary:19000,department:"OraApps"},
      {id:1003,name:"Vikash",salary:29000,department:"BI"},
  ];

  addEmployee(arg1:any,arg2:any,arg3:any,arg4:any){
    this.id=parseInt((<HTMLInputElement>arg1).value);
    this.name=(<HTMLInputElement>arg2).value;
    this.salary=parseInt((<HTMLInputElement>arg3).value);
    this.department=(<HTMLInputElement>arg4).value;
    //console.log(this.employeeDetails);
    this.employeeDetails.push({id:this.id,name:this.name,salary:this.salary,department:this.department});
    this.status=true;
    if(this.status==true){
      alert("inserted id: "+this.id+" name: "+this.name+" salary: "+this.salary+" department: "+this.department);

    }
  }
  
  deleteEmp(id:number)
  {
    for (let i = this.employeeDetails.length - 1; i>= 0; i--) {
        if (this.employeeDetails[i].id === id) {
            this.employeeDetails.splice(i, 1);
        }
    }
    alert("Data deleted");
  }
  newid:number;
  newname:string;
  newsalary:number;
  newdepartment:string;
  updateEmp(id:number,name:string,salary:number,department:string)
  {
    this.newid=id;
    this.newname=name;
    this.newsalary=salary;
    this.newdepartment=department;
    }

  editrow(id:number,name:string,salary:number,department:string)
  {
    for(let i=0;i<this.employeeDetails.length;i++){
      let em=this.employeeDetails[i];
      if(em.id==id){
        console.log(name);
        this.employeeDetails.splice(i,1);  
        this.employeeDetails.push({id,name,salary,department});
        console.log(em.name);
        break;
      }
  }
  }
  
}
