import { Injectable } from '@angular/core';
import { Product } from './product/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }

  sendData(product:Product){
    console.log(product);
  }
}
