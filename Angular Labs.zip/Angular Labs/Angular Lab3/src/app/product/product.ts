export class Product{

    constructor(private pid:number,private pname:string,private pcost:number,private ponline:string,
        private pcategory:string,private pavailable:string)
    {
        this.pid=pid;
        this.pname=pname;
        this.pcost=pcost;
        this.ponline=ponline;
        this.pcategory=pcategory;
        this.pavailable=pavailable;
    };
}