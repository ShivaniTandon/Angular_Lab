import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyForm';

  private id:string;
  private name: string;
  private sal:string;
  private dep:string;

  constructor(){

  }
  print(arg1:any,arg2:any,arg3:any,arg4:any):any{
    this.id=(<HTMLInputElement>arg1).value;
    this.name=(<HTMLInputElement>arg2).value;
    this.sal=(<HTMLInputElement>arg3).value;
    this.dep=(<HTMLInputElement>arg4).value;
    alert(this.id+" "+this.name+" "+this.sal+" "+this.dep);
    
  }
}
