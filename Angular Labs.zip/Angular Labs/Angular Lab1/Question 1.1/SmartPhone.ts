import { MobileComponent } from "./MobileComponent";

export class SmartPhone extends MobileComponent{
      private mobileType:string
  
      constructor(mobileId: number,mobileName: string,mobileCost: number, private mtype:string){
        super(mobileId,mobileName,mobileCost);
        this.mobileType=mtype;
        }

       printMobileInfo(){
          return this.printMobileDetails()+"\tMobile type is:\t"+this.mtype;
      }
    }
      let smartmobiles:SmartPhone[]=[
        new SmartPhone(101, "Realme 3", 12500,"SmartPhone"),
        new SmartPhone(102, "Realme 3 pro", 13000,"SmartPhone"),
        new SmartPhone(105, "Realme 5 pro", 12400,"SmartPhone")

    ]
    for(let i = 0; i < smartmobiles.length; i++) {
        console.log(smartmobiles[i].printMobileInfo());
        }
  


