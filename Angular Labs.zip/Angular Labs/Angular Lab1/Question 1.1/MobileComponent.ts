 export class MobileComponent{

  constructor(private mobileId: number, private mobileName: string, private mobileCost: number) {
    this.mobileId = mobileId;
    this.mobileName = mobileName;
    this.mobileCost = mobileCost;
  }
  printMobileDetails(){
    return "Mobile id is:\t" + this.mobileId + "\tMobile name is:\t" + this.mobileName + "\tMobile cost is:\t " + this.mobileCost;
  }
}