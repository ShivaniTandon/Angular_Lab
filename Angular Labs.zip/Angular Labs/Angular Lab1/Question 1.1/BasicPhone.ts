import { MobileComponent } from "./MobileComponent";

export class BasicPhone extends MobileComponent{
    private mobileType:string

    constructor(mobileId: number,mobileName: string,mobileCost: number, private mtype:string){
        super(mobileId,mobileName,mobileCost);
        this.mobileType=mtype;
        }

    printMobileInfo():string{
        return this.printMobileDetails()+"\tMobile type is:\t"+this.mtype;
    }
  }

    let basicmobiles:BasicPhone[]=[
      new BasicPhone(101, "Nokia", 12500," BasicPhone"),
      new BasicPhone(102, "Samsung", 13000,"BasicPhone"),
      new BasicPhone(105, "Realme", 12400," BasicPhone")
  ]

  for(let i = 0; i < basicmobiles.length; i++) {
      console.log(basicmobiles[i].printMobileInfo());
      }



